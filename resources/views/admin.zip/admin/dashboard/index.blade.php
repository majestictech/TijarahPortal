<?php
use Illuminate\Foundation\Auth\AuthenticatesUsers;
$Roles = config('app.Roles');
?>

@include('admin.layout.header')

<div class="row row-cols-1 row-cols-md-2 row-cols-xl-5">
	<div class="col">
		<div class="card radius-10 overflow-hidden">
			<div class="card-body">
				<div class="d-flex align-items-center">
					<div>
						<p class="mb-0 text-secondary font-14"><a href="{{url('/admin/order')}}">{{ __('lang.todaysorders')}}</a></p>
						<h5 class="my-0">80</h5>
					</div>
					<div class="text-primary ms-auto font-30"><i class='bx bx-cart-alt'></i>
					</div>
				</div>
			 </div>
			<div class="mt-1" id="chart1"></div>
		</div>
	</div>
	<div class="col">
		<div class="card radius-10 overflow-hidden">
			<div class="card-body">
				<div class="d-flex align-items-center">
					<div>
						<p class="mb-0 text-secondary font-14"><a href="{{url('/admin/order')}}">{{ __('lang.totalorders')}}</a></p>
						<h5 class="my-0">1252</h5>
					</div>
					<div class="text-info ms-auto font-30"><i class='bx bx-cart'></i>
					</div>
				</div>
			</div>
			<div class="mt-1" id="chart5"></div>
		</div>
	</div>
	
	<div class="col">
		<div class="card radius-10 overflow-hidden">
			<div class="card-body">
				<div class="d-flex align-items-center">
					<div>
						<p class="mb-0 text-secondary font-14"><a href="{{url('/admin/report/revenue')}}">{{ __('lang.todaysrevenue')}}</a></p>
						<h5 class="my-0">SAR 500</h5>
					</div>
					<div class="text-danger ms-auto font-30">ريال
					</div>
				</div>
			</div>
			<div class="mt-1" id="chart2"></div>
		</div>
	</div>
	<div class="col">
		<div class="card radius-10 overflow-hidden">
			<div class="card-body">
				<div class="d-flex align-items-center">
					<div>
						<p class="mb-0 text-secondary font-14"><a href="{{url('/admin/customer')}}">{{ __('lang.customers')}}</a></p>
						<h5 class="my-0">2432</h5>
					</div>
					<div class="text-success ms-auto font-30"><i class='bx bx-group'></i>
					</div>
				</div>
			</div>
			<div class="mt-1" id="chart3"></div>
		</div>
	</div>
	<div class="col">
		<div class="card radius-10 overflow-hidden">
			<div class="card-body">
				<div class="d-flex align-items-center">
					<div>
						<p class="mb-0 text-secondary font-14"><a href="{{url('/admin/store')}}">{{ __('lang.activestores')}}</a></p>
						<h5 class="my-0">956</h5>
					</div>
					<div class="text-warning ms-auto font-30"><i class='bx bx-store-alt'></i>
					</div>
				</div>
			</div>
			<div class="mt-1" id="chart4"></div>
		</div>
	</div>
	
</div><!--end row-->


<div class="row">
	<div class="col-12 col-lg-8">
		<div class="card radius-10">
			<div class="card-body">
			   <div class="d-flex align-items-center">
				   <div>
					   <h6 class="mb-0">{{ __('lang.salesoverview')}}</h6>
				   </div>
				   <div class="dropdown ms-auto">
					   <a class="dropdown-toggle dropdown-toggle-nocaret" href="#" data-bs-toggle="dropdown"><i class='bx bx-dots-horizontal-rounded font-22 text-option'></i>
					   </a>
					   <ul class="dropdown-menu">
						   <li><a class="dropdown-item" href="javascript:;">{{ __('lang.action')}}</a>
						   </li>
						   <li><a class="dropdown-item" href="javascript:;">{{ __('lang.anotheraction')}}</a>
						   </li>
						   <li>
							   <hr class="dropdown-divider">
						   </li>
						   <li><a class="dropdown-item" href="javascript:;">{{ __('lang.somethingelsehere')}}</a>
						   </li>
					   </ul>
				   </div>
			   </div>
			 <div class="chart-container-0">
			   <canvas id="chart7"></canvas>
			</div>
			</div>
		 </div>
	</div>
	<div class="col-12 col-lg-4">
		<div class="card radius-10">
			<div class="card-body">
				<div class="d-flex align-items-center">
					<div>
						<h6 class="mb-0">{{ __('lang.orderstatus')}}</h6>
					</div>
					<div class="dropdown ms-auto">
						<a class="dropdown-toggle dropdown-toggle-nocaret" href="#" data-bs-toggle="dropdown"><i class='bx bx-dots-horizontal-rounded font-22 text-option'></i>
						</a>
						<ul class="dropdown-menu">
							<li><a class="dropdown-item" href="javascript:;">{{ __('lang.action')}}</a>
							</li>
							<li><a class="dropdown-item" href="javascript:;">{{ __('lang.anotheraction')}}</a>
							</li>
							<li>
								<hr class="dropdown-divider">
							</li>
							<li><a class="dropdown-item" href="javascript:;">{{ __('lang.somethingelsehere')}}</a>
							</li>
						</ul>
					</div>
				</div>
				<div class="chart-container-0">
					<canvas id="chart-order-status"></canvas>
				 </div>
			</div>
		</div>
	</div>
</div><!--end row-->

@include('admin.layout.footer')