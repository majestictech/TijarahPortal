
@include('admin.layout.header')
 
 <div class="content-page">
     <div class="container-fluid add-form-list">
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header d-flex justify-content-between">
                        <div class="header-title">
                            <h4 class="card-title">{{ __('lang.addbrand')}}</h4>
                        </div>
                    </div>
                    <div class="card-body">
                        <form action="{{route('brand.store')}}" data-toggle="validator" method ="post"  enctype="multipart/form-data">
						@csrf
                            <div class="row">
                              
                                <div class="col-md-6">                      
                                    <div class="form-group">
                                        <label>{{ __('lang.brandtitle')}} *</label>
                                        <input type="text" class="form-control" name="brandName" placeholder="{{ __('lang.enterbrandtitle')}}" data-error="{{ __('lang.req_brandtitle')}}" required>
                                        <div class="help-block with-errors"></div>
                                    </div>
                                </div>    
								
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>{{ __('lang.brandimage')}} *</label>
                                    	<input type="file" name="brandImage" data-error="{{ __('lang.req_image')}}" class="image-file form-control" required>
										<div class="help-block with-errors"></div>
                                    </div>
                                </div>
								<div class="col-md-6">
                                    <div class="form-group">
                                        <label>{{ __('lang.brandfeaturedimage')}} *</label>
                                    	<input type="file" name="brandFeaturedImage" data-error="{{ __('lang.req_image')}}" class="image-file form-control" required>
										<div class="help-block with-errors"></div>
                                    </div>
                                </div>
								<div class="col-md-6">								
									<div class="form-group">
									  <label>{{ __('lang.featuredbrand')}}</label><br/>
									  <input class="radio-input mr-2" type="radio" id="yes" value="Yes" name="featuredbrand" checked>
									  <label class="mb-0" for="yes">
										{{ __('lang.yes')}}
									  </label>
									
									  <input class="checkbox-input mr-2 ml-2" type="radio" value="No" id="no" name="featuredbrand">
									  <label class="mb-0" for="no">
										{{ __('lang.no')}}
									  </label>
									</div>
                                </div>
															
                     
                            </div>                            
                            <button type="submit" class="btn btn-primary mr-2">{{ __('lang.addbrand')}}</button>
                            <button type="reset" class="btn btn-danger">{{ __('lang.reset')}}</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- Page end  -->
    </div>
      </div>
    </div>
    <!-- Wrapper End-->
@include('admin.layout.footer')