
@include('admin.layout.header')
   <div class="content-page">
     <div class="container-fluid">
                <div class="row">
            <div class="col-lg-12">
                <div class="d-flex flex-wrap align-items-center justify-content-between mb-4">
                    <div>
                        <h4 class="mb-3">{{ __('lang.storedetails')}}</h4>
                        <p class="mb-0">{{ __('lang.storedetailsdesc')}}</p>
                    </div>
                    <a href="{{url('/admin/store')}}" class="btn btn-primary add-list">{{ __('lang.storelist')}}</a>
                </div>
            </div>
			
		    <div class="col-lg-9">
			  <div class="table-responsive rounded mb-3">
                <table class="data-table table mb-0 tbl-server-info">
                 
                    <tbody >
                        
					    <tr>
                            <td><b>Store ID</b></td> 
                            <td>{{$storedata->id}}</td> 
							
						</tr>
						
                        <tr class="table-active">
                            <td><b>Store Name</b></td> 
                            <td>{{$storedata->storeName}}</td> 
							
						</tr>
						<tr>
                            <td><b>Registration Number</b></td>
                            <td>{{$storedata->regNo}}</td>
						</tr>
						
						<tr class="table-active">
                            <td><b>Store Type</b></td>
                            <td>{{$storedata->name}}</td>
						</tr>
						
						<tr >
                            <td><b>Contact Name</b></td>
                            <td>{{$storedata->firstName}}{{$storedata->lastName}}</td>
						</tr>
						<tr class="table-active">
                            <td><b>Contact Number</b></td>
                            <td>{{$storedata->contactNumber}}</td>
						</tr >
						<tr >
                            <td><b>Device Type</b></td>
                            <td>{{$storedata->deviceType}}</td>
						</tr >
						<tr class="table-active">
                            <td><b>App Type</b></td>
                            <td>{{$storedata->appType}}</td>
						</tr>
						<tr >
                            <td><b>Shop Size</b></td>
                            <td>{{$storedata->shopSize}}</td>
						</tr >
						<tr class="table-active">
                            <td><b>VAT Number</b></td>
                            <td>{{$storedata->vatNumber}}</td>
						</tr >
						<tr >
							<td><b>State</b></td>
							<td>{{$storedata->state}}</td>
						</tr>
						<tr class="table-active">
                            <td><b>Country</b></td>
                            <td>{{$storedata->nicename}}</td>
						</tr>
                    	<tr >
                            <td><b>Inventory Link</b></td>
                            <td>{{$storedata->manageInventory}}</td>
						</tr >
						<tr class="table-active">
                            <td><b>SMS Alerts</b></td>
                            <td>{{$storedata->smsAlert}}</td>
						</tr>
						<tr >
                            <td><b>Auto upload global categories</b></td>
                            <td>{{$storedata->autoGlobalCat}}</td>
						</tr >
						<tr class="table-active">
                            <td><b>Online Market place</b></td>
                            <td>{{$storedata->onlineMarket}}</td>
						</tr >
						<tr >
							<td><b>Loyalty Options</b></td>
							<td>{{$storedata->loyaltyOptions}}</td>
						</tr>
						<tr class="table-active">
                            <td><b>Auto upload global items</b></td>
                            <td>{{$storedata->autoGlobalItems}}</td>
						</tr>

						<tr >
							<td><b>Chatbot</b></td>
							<td>{{$storedata->chatbot}}</td>
						</tr>
						
						<tr >
                            <td><b>Latitude</b></td>
                            <td>{{$storedata->latitude}}</td>
						</tr>
						
						<tr class="table-active">
                            <td><b>Longitude</b></td>
                            <td>{{$storedata->longitude}}</td>
						</tr>
						
                        
						<tr >
                            <td><b>Store Address</b></td>
                            <td>{{$storedata->address}}</td>
						</tr>
						
						<tr class="table-active">
                            <td><b>ECR App Version</b></td>
                            <td>{{$storedata->appVersion}}</td>
						</tr>
                                   
                                                  
                    </tbody>
                </table>
                </div>
      
            </div>
			
			
        </div>
        <!-- Page end  -->
    </div>
    
      </div>
    </div>
    <!-- Wrapper End-->
@include('admin.layout.footer')