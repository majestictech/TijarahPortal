@include('admin.layout.header')							

<!--breadcrumb-->
<div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
	<div class="ps-1">
		<nav aria-label="breadcrumb">
			<ol class="breadcrumb mb-0 p-0">
				<li class="breadcrumb-item"><a class="text-primary" href="{{url('admin')}}"><i class="bx bx-home-alt"></i> {{ __('lang.dashboards')}}</a>
				</li>
				<li class="breadcrumb-item active" aria-current="page"><i class="bx bx-store-alt"></i> {{ __('lang.stores')}}</li>
			</ol>
		</nav>
	</div>
	<div class="ms-auto">
		<div class="btn-group">
			<a href="{{url('/admin/store/create')}}" class="btn btn-primary"><i class="fadeIn animated bx bx-list-plus"></i> {{ __('lang.addstore')}}</a>
		</div>
	</div>
</div>
<!--end breadcrumb-->
<div class="row">
	<div class="col-xl-12 mx-auto">
		<h6 class="mb-0 text-uppercase">All Stores</h6>
		<hr/>
		<div class="card">
			<div class="card-body">
				<table class="table mb-0 table-striped table-bordered" id="myTable">
					<thead>
						<tr>
							<th scope="col">{{ __('lang.storename')}}</th>
							<th scope="col">{{ __('lang.appVersion')}}</th>
							<th scope="col">{{ __('lang.lastbill')}}</th>
							<th scope="col">{{ __('lang.totalorders')}}</th>
							<th scope="col">{{ __('lang.todaysorders')}}</th>
							<th scope="col" width="15%">{{ __('lang.action')}}</th>
						</tr>
					</thead>
					<tbody>
					@foreach($stores as $key =>$StoreData)
						<tr>
                            <td>{{$StoreData->storeName}}</td>
                            <td>{{$StoreData->appVersion}}</td>
                            <td>17th May 2021</td>
							<td>40253</td>
                            <td>50</td>
                            
                            <td>
								<div class="btn-group">
									<button type="button" class="btn btn-primary split-bg-primary dropdown-toggle dropdown-toggle-split" data-bs-toggle="dropdown"><i class="bx bx-show"></i>
									</button>
									<div class="dropdown-menu dropdown-menu-right dropdown-menu-lg-end">
										<!--<a class="dropdown-item" href="{{url('/admin/category/'.$StoreData->id)}}"><i class="fadeIn animated bx bx-spreadsheet"></i> Categories</a>-->
										<a class="dropdown-item" href="{{url('/admin/store/'.$StoreData->id.'/edit')}}"><i class="fadeIn animated bx bx-edit"></i> {{ __('lang.edit')}}</a>
										<a class="dropdown-item" href="{{url('/admin/store/'.$StoreData->id.'/disable')}}" onclick="return confirm('Are you sure you want to disable the store?');"><i class="fadeIn animated bx bx-trash"></i> {{ __('lang.disable')}}</a>
										<a class="dropdown-item" href="{{url('/admin/cashier/'.$StoreData->id)}}"><i class="fadeIn animated bx bx-trash"></i> {{ __('lang.storecashiers')}}</a>
										<a class="dropdown-item" href="#"><i class="fas fa-boxes"></i> {{ __('lang.lowinventory')}}</a>
										<a class="dropdown-item" href="#"><i class="fadeIn animated bx bx-trash"></i> {{ __('lang.configemail')}}</a>
										<a class="dropdown-item" href="{{url('/admin/product/'.$StoreData->id)}}"><i class="fadeIn animated bx bx-check-circle"></i> {{ __('lang.inventory')}}</a>
										<a class="dropdown-item" href="{{url('/admin/store/'.$StoreData->id.'/view')}}"><i class="bx bx-show"></i> {{ __('lang.view')}}</a>
										<a class="dropdown-item" href="{{url('/admin/store/'.$StoreData->id.'/zeroinventory')}}" onclick="return confirm('Are you sure you want to zero the inventory?');"><i class="fadeIn animated bx bx-trash"></i> {{ __('lang.zeroinventory')}}</a>
										<a class="dropdown-item" href="{{url('/admin/store/'.$StoreData->id.'/emptyinventory')}}"  onclick="return confirm('Are you sure you want to empty the inventory?');"><i class="fadeIn animated bx bx-trash"></i> {{ __('lang.emptyinventory')}}</a>
										<a class="dropdown-item" href="#"><i class="fadeIn animated bx bx-trash"></i> {{ __('lang.purchases')}}</a>
										<a class="dropdown-item" href="{{url('/admin/order/'.$StoreData->id)}}"><i class="fadeIn animated bx bx-trash"></i> {{ __('lang.bills')}}</a>
										<a class="dropdown-item" href="{{url('/admin/report/sales')}}"><i class="fadeIn animated bx bx-trash"></i> {{ __('lang.sales')}}</a>
										<a class="dropdown-item" href="{{url('/admin/shift/'.$StoreData->id)}}"><i class="fadeIn animated bx bx-time"></i> {{ __('lang.shifts')}}</a>
										<a class="dropdown-item" href="{{url('/admin/purchaseorder/'.$StoreData->id)}}"><i class="fadeIn animated bx bx-basket"></i> {{ __('lang.purchaseorderpo')}}</a>
										<a class="dropdown-item" href="{{url('/admin/invoice/'.$StoreData->id)}}"><i class="fadeIn animated bx bx-detail"></i> {{ __('lang.invoices')}}</a>
										<!--
										<div class="dropdown-divider"></div>
										<a class="dropdown-item" href="#"><i class="fadeIn animated bx bx-log-in"></i> Login As</a>
										-->
									</div>
								</div>
							</td>
						</tr>
					@endforeach
					</tbody>
				</table>

			</div>
		</div>
	</div>
</div>
<!--end row-->


@include('admin.layout.footer')
<script src=//code.jquery.com/jquery-3.5.1.slim.min.js integrity="sha256-4+XzXVhsDmqanXGHaHvgh1gMQKX40OUvDEBTu8JcmNs=" crossorigin=anonymous></script
<script>
 
var table = $('#myTable').DataTable({
   "order": [[ 1, "asc" ]],
              'columnDefs': [{
                    "targets": [5],
                    "orderable": false
                }]
          });
</script>