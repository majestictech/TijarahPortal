@include('admin.layout.header')							

<!--breadcrumb-->
<div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
	<div class="ps-1">
		<nav aria-label="breadcrumb">
			<ol class="breadcrumb mb-0 p-0">
				<li class="breadcrumb-item"><a class="text-primary" href="{{url('admin')}}"><i class="bx bx-home-alt"></i> {{ __('lang.dashboards')}}</a>
				</li>
				<li class="breadcrumb-item active" aria-current="page"><i class="bx bx-list-ol"></i> {{ __('lang.orders')}}</li>
			</ol>
		</nav>
	</div>
</div>
<!--end breadcrumb-->
<div class="row">
	<div class="col-xl-12 mx-auto">
		<h6 class="mb-0 text-uppercase">{{ __('lang.allorders')}}</h6>
		<hr/>
		<div class="card">
			<div class="card-body">
			    <div class="row input-daterange pb-4">
                    <div class="col-md-4">
                        <input type="date" name="max" id="max" class="form-control" placeholder="{{ __('lang.fromdate')}}"  />
                    </div>
                    <div class="col-md-4">
                        <input type="date" name="min" id="min" class="form-control" placeholder="{{ __('lang.todate')}}"  />
                    </div>
                    <!--<div class="col-md-4">
                        <button type="button" name="filter" id="filter" class="btn btn-primary">Filter</button>
                        <button type="button" name="refresh" id="refresh" class="btn btn-default">Refresh</button>
                    </div>-->
                </div>
				<table class="table mb-0 table-striped table-bordered" id="myTable">
					<thead>
						<tr>
							<th scope="col">{{ __('lang.placedon')}}</th>
							<th scope="col">{{ __('lang.ordernumber')}}</th>
							<th scope="col">{{ __('lang.payment')}}</th>
							<th scope="col">{{ __('lang.action')}}</th>
						</tr>
					</thead>
					<tbody>
					@foreach($orders as $key =>$orderData)
						<tr>
                            <td>{{\Carbon\Carbon::parse($orderData->created_at)->format('d M Y')}}</td>
                            <td>{{$orderData->orderId}}</td>
                            <td>SAR {{$orderData->totalAmount}}</td>
                            <td>
								<div class="btn-group">
									<button type="button" class="btn btn-primary split-bg-primary dropdown-toggle dropdown-toggle-split" data-bs-toggle="dropdown"><i class="fadeIn animated bx bx-show"></i>
									</button>
									<div class="dropdown-menu dropdown-menu-right dropdown-menu-lg-end">
										<a class="dropdown-item" href="{{url('/admin/order/'.$orderData->id.'/view')}}"><i class="fadeIn animated bx bx-show"></i> {{ __('lang.view')}}</a>
									</div>
								</div>
							</td>
						</tr>
					@endforeach
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
<!--end row-->

@include('admin.layout.footer')

<script>
var minDate, maxDate;
 
// Custom filtering function which will search data in column four between two values
$.fn.dataTable.ext.search.push(
    function( settings, data, dataIndex ) {
        var min = minDate.val();
        var max = maxDate.val();
        var date = new Date( data[2] );
 
        if (
            ( min === null && max === null ) ||
            ( min === null && date <= max ) ||
            ( min <= date   && max === null ) ||
            ( min <= date   && date <= max )
        ) {
            return true;
        }
        return false;
    }
);
 
$(document).ready(function() {
    // Create date inputs
    minDate = new DateTime($('#min'), {
        format: 'MMMM Do YYYY'
    });
    maxDate = new DateTime($('#max'), {
        format: 'MMMM Do YYYY'
    });
 
    // DataTables initialisation
    var table = $('#myTable').DataTable();
 
    // Refilter the table
    $('#min, #max').on('change', function () {
        table.draw();
    });
});
</script>

<script>
var table = $('#myTable').DataTable({
   "order": [[ 1, "asc" ]],
              'columnDefs': [{
                    "targets": [2,3],
                    "orderable": false
                }]
          });
</script>