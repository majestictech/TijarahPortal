
@include('admin.layout.header')
   <div class="page-wrapper">
   <div class="page-content">
   Test
    </div>
    </div>
    </div>
    <!-- Wrapper End-->
@include('admin.layout.footer')