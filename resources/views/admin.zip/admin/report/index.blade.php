@include('admin.layout.header')

@if($type == "Sales")
<div class="row">
	<div class="col-12">
		<div class="card radius-10">
			<div class="card-body">
			   <div class="d-flex align-items-center">
				   <div>
					   <h6 class="mb-0">{{$type}} {{ __('lang.reports')}}</h6>
				   </div>
				   <div class="dropdown ms-auto">
					   <a class="dropdown-toggle dropdown-toggle-nocaret" href="#" data-bs-toggle="dropdown"><i class='bx bx-dots-horizontal-rounded font-22 text-option'></i>
					   </a>
					   <ul class="dropdown-menu">
						   <li><a class="dropdown-item" href="javascript:;">{{ __('lang.action')}}</a>
						   </li>
						   <li><a class="dropdown-item" href="javascript:;">{{ __('lang.anotheraction')}}</a>
						   </li>
						   <li>
							   <hr class="dropdown-divider">
						   </li>
						   <li><a class="dropdown-item" href="javascript:;">{{ __('lang.somethingelsehere')}}</a>
						   </li>
					   </ul>
				   </div>
			   </div>
			 <div class="chart-container-0">
			   <canvas id="chart7"></canvas>
			</div>
			</div>
		 </div>
	</div>
</div><!--end row-->
@endif

@if($type == "Revenue")
<div class="row">
	<div class="col-12">
		<div class="card radius-10">
			<div class="card-body">
			   <div class="d-flex align-items-center">
				   <div>
					   <h6 class="mb-0">{{$type}} {{ __('lang.reports')}}</h6>
				   </div>
				   <div class="dropdown ms-auto">
					   <a class="dropdown-toggle dropdown-toggle-nocaret" href="#" data-bs-toggle="dropdown"><i class='bx bx-dots-horizontal-rounded font-22 text-option'></i>
					   </a>
					   <ul class="dropdown-menu">
						   <li><a class="dropdown-item" href="javascript:;">{{ __('lang.action')}}</a>
						   </li>
						   <li><a class="dropdown-item" href="javascript:;">{{ __('lang.anotheraction')}}</a>
						   </li>
						   <li>
							   <hr class="dropdown-divider">
						   </li>
						   <li><a class="dropdown-item" href="javascript:;">{{ __('lang.somethingelsehere')}}</a>
						   </li>
					   </ul>
				   </div>
			   </div>
			 <div class="chart-container-0">
			   <canvas id="chart7"></canvas>
			</div>
			</div>
		 </div>
	</div>
</div><!--end row-->
@endif

@if($type == "Averagebasket")
<div class="row">
	<div class="col-12">
		<div class="card radius-10">
			<div class="card-body">
			   <div class="d-flex align-items-center">
				   <div>
					   <h6 class="mb-0">{{$type}} {{ __('lang.reports')}}</h6>
				   </div>
				   <div class="dropdown ms-auto">
					   <a class="dropdown-toggle dropdown-toggle-nocaret" href="#" data-bs-toggle="dropdown"><i class='bx bx-dots-horizontal-rounded font-22 text-option'></i>
					   </a>
					   <ul class="dropdown-menu">
						   <li><a class="dropdown-item" href="javascript:;">{{ __('lang.action')}}</a>
						   </li>
						   <li><a class="dropdown-item" href="javascript:;">{{ __('lang.anotheraction')}}</a>
						   </li>
						   <li>
							   <hr class="dropdown-divider">
						   </li>
						   <li><a class="dropdown-item" href="javascript:;">{{ __('lang.somethingelsehere')}}</a>
						   </li>
					   </ul>
				   </div>
			   </div>
			 <div class="chart-container-0">
			   <canvas id="chart7"></canvas>
			</div>
			</div>
		 </div>
	</div>
</div><!--end row-->
@endif

@if($type == "Bills")
<div class="row">
	<div class="col-12">
		<div class="card radius-10">
			<div class="card-body">
			   <div class="d-flex align-items-center">
				   <div>
					   <h6 class="mb-0">{{$type}} {{ __('lang.reports')}}</h6>
				   </div>
				   <div class="dropdown ms-auto">
					   <a class="dropdown-toggle dropdown-toggle-nocaret" href="#" data-bs-toggle="dropdown"><i class='bx bx-dots-horizontal-rounded font-22 text-option'></i>
					   </a>
					   <ul class="dropdown-menu">
						   <li><a class="dropdown-item" href="javascript:;">{{ __('lang.action')}}</a>
						   </li>
						   <li><a class="dropdown-item" href="javascript:;">{{ __('lang.anotheraction')}}</a>
						   </li>
						   <li>
							   <hr class="dropdown-divider">
						   </li>
						   <li><a class="dropdown-item" href="javascript:;">{{ __('lang.somethingelsehere')}}</a>
						   </li>
					   </ul>
				   </div>
			   </div>
			 <div class="chart-container-0">
			   <canvas id="chart7"></canvas>
			</div>
			</div>
		 </div>
	</div>
</div><!--end row-->
@endif

@if($type == "Stock")
<div class="row">
	<div class="col-12">
		<div class="card radius-10">
			<div class="card-body">
			   <div class="d-flex align-items-center">
				   <div>
					   <h6 class="mb-0">{{$type}} {{ __('lang.reports')}}</h6>
				   </div>
				   <div class="dropdown ms-auto">
					   <a class="dropdown-toggle dropdown-toggle-nocaret" href="#" data-bs-toggle="dropdown"><i class='bx bx-dots-horizontal-rounded font-22 text-option'></i>
					   </a>
					   <ul class="dropdown-menu">
						   <li><a class="dropdown-item" href="javascript:;">{{ __('lang.action')}}</a>
						   </li>
						   <li><a class="dropdown-item" href="javascript:;">{{ __('lang.anotheraction')}}</a>
						   </li>
						   <li>
							   <hr class="dropdown-divider">
						   </li>
						   <li><a class="dropdown-item" href="javascript:;">{{ __('lang.somethingelsehere')}}</a>
						   </li>
					   </ul>
				   </div>
			   </div>
			 <div class="chart-container-0">
			   <canvas id="chart7"></canvas>
			</div>
			</div>
		 </div>
	</div>
</div><!--end row-->
@endif

@if($type == "Dailysummary")
<div class="row">
	<div class="col-12">
		<div class="card radius-10">
			<div class="card-body">
			   <div class="d-flex align-items-center">
				   <div>
					   <h6 class="mb-0">{{$type}} {{ __('lang.reports')}}</h6>
				   </div>
				   <div class="dropdown ms-auto">
					   <a class="dropdown-toggle dropdown-toggle-nocaret" href="#" data-bs-toggle="dropdown"><i class='bx bx-dots-horizontal-rounded font-22 text-option'></i>
					   </a>
					   <ul class="dropdown-menu">
						   <li><a class="dropdown-item" href="javascript:;">{{ __('lang.action')}}</a>
						   </li>
						   <li><a class="dropdown-item" href="javascript:;">{{ __('lang.anotheraction')}}</a>
						   </li>
						   <li>
							   <hr class="dropdown-divider">
						   </li>
						   <li><a class="dropdown-item" href="javascript:;">{{ __('lang.somethingelsehere')}}</a>
						   </li>
					   </ul>
				   </div>
			   </div>
			 <div class="chart-container-0">
			   <canvas id="chart7"></canvas>
			</div>
			</div>
		 </div>
	</div>
</div><!--end row-->
@endif

@if($type == "Hsn")
<div class="row">
	<div class="col-12">
		<div class="card radius-10">
			<div class="card-body">
			   <div class="d-flex align-items-center">
				   <div>
					   <h6 class="mb-0">{{$type}} {{ __('lang.reports')}}</h6>
				   </div>
				   <div class="dropdown ms-auto">
					   <a class="dropdown-toggle dropdown-toggle-nocaret" href="#" data-bs-toggle="dropdown"><i class='bx bx-dots-horizontal-rounded font-22 text-option'></i>
					   </a>
					   <ul class="dropdown-menu">
						   <li><a class="dropdown-item" href="javascript:;">{{ __('lang.action')}}</a>
						   </li>
						   <li><a class="dropdown-item" href="javascript:;">{{ __('lang.anotheraction')}}</a>
						   </li>
						   <li>
							   <hr class="dropdown-divider">
						   </li>
						   <li><a class="dropdown-item" href="javascript:;">{{ __('lang.somethingelsehere')}}</a>
						   </li>
					   </ul>
				   </div>
			   </div>
			 <div class="chart-container-0">
			   <canvas id="chart7"></canvas>
			</div>
			</div>
		 </div>
	</div>
</div><!--end row-->
@endif

@include('admin.layout.footer')